# About SI114H Final Project

## Code
All the codes about the project are under the `Code` directory, all are matlab files.

## References

All the main citations are under the `Reference` directory.

## Requirements
To run this project, you need to have the following installed:

- Matlab

## Everyone's Contribution

- QianYu Chen: Algorithm code development of Finite Element Analysis, Shear Locking and Modal Analysis and report writing.
- Mokai Pan: Algorithm code development of Finite Difference Method, experiment result analysis and report writing.
- Yu Shi: Code integration, data visualisation and report writing.
